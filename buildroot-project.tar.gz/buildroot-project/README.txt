Buildroot må pakkes ut eller klones med git inn i buildroot-katalogen!
